export function isBj(element: HTMLElement) {
  return element.classList.contains('bj')
}
