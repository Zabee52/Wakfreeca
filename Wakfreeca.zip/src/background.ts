chrome.action.onClicked.addListener(function () {
  chrome.tabs.create({ url: 'https://github.com/Zabee52/Wakfreeca' })
})
